/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

import OrderDAO.OrderDAO;
import OrderDAO.OrderDetailDAO;
import ProductDAO.ProductDAO;
import context.DBContext;
import java.sql.Connection;
import entity.Order;
import entity.OrderDetail;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author admin
 */
public class OrderService {
    Connection conn = DBContext.getConnection();
    private final OrderDAO orderDAO;
    private final OrderDetailDAO orderDetailDAO;
    private final ProductDAO productDAO;
    
    public OrderService() {
        this.orderDAO = new OrderDAO(conn);
        this.orderDetailDAO = new OrderDetailDAO(conn);
        this.productDAO = new ProductDAO();
    }

    public boolean placeOrder(int userId, List<OrderDetail> cartItems){
        try {
            conn.setAutoCommit(false);
            double totalPrice = 0;
            for (OrderDetail item : cartItems) {
                totalPrice += item.getQuantity() * item.getPrice();
            }
            
            int orderId = orderDAO.createOrder(userId, totalPrice, "PENDING", LocalDateTime.now());
            if (orderId == -1) {
                conn.rollback();
                return false;
            }
            
            for (OrderDetail item : cartItems) {
                int stock = productDAO.getStockByProductId(item.getProductId());
                if (stock < item.getQuantity()) {
                    conn.rollback(); 
                    return false;
                }
                productDAO.updateProductStock(item.getProductId(), stock - item.getQuantity());

                item.setOrderId(orderId);
                orderDetailDAO.addOrderDetail(item);
            }
            conn.commit(); 
            return true;
        } catch (Exception e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public List<OrderDetail> getOrderDetailsByOrderId(int orderId) throws SQLException {
        return orderDetailDAO.getOrderDetailsByOrderId(orderId);
    }
        
    public List<Order> getOrdersByUserId(int userId) throws SQLException {
        return orderDAO.getOrdersByUserId(userId);
    }
    
    public List<Order> getAllOrders() throws SQLException {
        return orderDAO.getAllOrders();
    }
    
    public boolean updateOrderStatus(int orderId, String newStatus) throws SQLException {
        return orderDAO.updateOrderStatus(orderId, newStatus);
    }

    public int generateOrderId() {
        return orderDAO.generateOrderId();
    }
    
    
}
