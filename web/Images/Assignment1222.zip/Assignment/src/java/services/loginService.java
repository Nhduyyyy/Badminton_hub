package services;

import LoginGoogle.UserGoogleDto;
import java.sql.SQLException;
import UserDAO.UserDAO;
import entity.Role;
import entity.User;

public class loginService {

    private UserDAO userDao = new UserDAO();

    // Phương thức xác thực đăng nhập
    public User authenticate(String identifier, String password) {
        return userDao.authenticateUser(identifier, password);
    }

    // Phương thức đăng nhập bằng Google
    public User authenticateGoogle(UserGoogleDto googleUser) {
    // Tìm kiếm người dùng theo email từ Google
    User user = userDao.findByEmail(googleUser.getEmail());
    if (user == null) {
        // Kiểm tra Role mặc định: Lưu ý xác nhận lại RoleID trong DB của bạn.
        Role defaultRole = new Role(3, "User", "Nguoi dung thong thuong");
        user = new User();
        user.setEmail(googleUser.getEmail());
        user.setUsername(googleUser.getEmail()); // hoặc có thể dùng googleUser.getName()
        user.setFullName(googleUser.getName());
        user.setAvatar(googleUser.getPicture());
        user.setPassword(""); // Với Google, có thể để trống mật khẩu
        user.setRole(defaultRole);
        
        // Thiết lập các thông tin mặc định khác
        user.setPhoneNumber("");             // Số điện thoại rỗng
        user.setScore(0);                    // Điểm mặc định là 0
        user.setSex("Unknown");              // Giới tính mặc định
        user.setBirthDate(new java.util.Date()); // Set ngày sinh là ngày hiện tại
        user.setLocked(false);               // Mặc định tài khoản không bị khóa
        
        try {
            userDao.insertUser(user);
            // Sau khi insert, lấy lại thông tin người dùng mới tạo
            user = userDao.findByEmail(googleUser.getEmail());
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    return user;
}


}
