/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OrderDAO;
import context.DBContext;
import java.sql.*;
import entity.OrderDetail;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author admin
 */
public class OrderDetailDAO {
    
    private Connection conn;

    public OrderDetailDAO() {
    }

    public OrderDetailDAO(Connection conn) {
        this.conn = DBContext.getConnection();
    }
    
    public void addOrderDetail(OrderDetail orderDetail) throws SQLException {
        String sql = "INSERT INTO OrderDetails (order_id, product_id,product_image,product_name, quantity, price, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderDetail.getOrderId());
            stmt.setInt(2, orderDetail.getProductId());
            stmt.setString(3, orderDetail.getProductImage());
            stmt.setString(4, orderDetail.getProductName());
            stmt.setInt(5, orderDetail.getQuantity());
            stmt.setDouble(6, orderDetail.getPrice());
            stmt.setDouble(7, orderDetail.getQuantity() * orderDetail.getPrice());
            stmt.executeUpdate();
        }
    }
    
    public List<OrderDetail> getOrderDetailsByOrderId(int orderId) throws SQLException {
        List<OrderDetail> orderDetails = new ArrayList<>();
        String sql = "SELECT od.*, p.image,p.product_name  FROM OrderDetails  od JOIN Products p ON od.product_id = p.product_id WHERE od.order_id = ?";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orderDetails.add(new OrderDetail(
                    rs.getInt("order_detail_id"),
                    rs.getInt("order_id"),
                    rs.getInt("product_id"),
                    rs.getString("image"),
                    rs.getString("product_name"),                    rs.getInt("quantity"),
                    rs.getDouble("price"),
                    rs.getDouble("total_price")
                ));
            }
        }
        return orderDetails;
    }
    
}
