/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OrderDAO;

import context.DBContext;
import entity.Order;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class OrderDAO {
    private Connection conn;

    public OrderDAO(Connection conn) {
        this.conn = DBContext.getConnection();
    }

    
    public int createOrder(int userId, double totalPrice, String status, LocalDateTime orderDate) throws SQLException {
        String sql = "INSERT INTO Orders (user_id, total_price, status, order_date) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1,userId);
            pstmt.setDouble(2,totalPrice);
            pstmt.setString(3,status);
            pstmt.setTimestamp(4, Timestamp.valueOf(orderDate));
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return -1;
    }
    
    public List<Order> getOrdersByUserId(int userId) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM Orders WHERE user_id = ? ORDER BY order_date DESC";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(new Order(
                    rs.getInt("order_id"),
                    rs.getInt("user_id"),
                    rs.getDouble("total_price"),
                    rs.getString("status"),
                    rs.getTimestamp("order_date").toLocalDateTime()
                ));
            }
        }
        return orders;
    }
    
    public List<Order> getAllOrders() throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM Orders ORDER BY order_date DESC";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orders.add(new Order(
                    rs.getInt("order_id"),
                    rs.getInt("user_id"),
                    rs.getDouble("total_price"),
                    rs.getString("status"),
                    rs.getTimestamp("order_date").toLocalDateTime()
               
                    
                ));
            }
        }
        return orders;
    }
    
    public boolean updateOrderStatus(int orderId, String newStatus) throws SQLException {
        String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    public int generateOrderId() {
        int orderId = -1;
        String sql = "INSERT INTO Orders (user_id, total_price) VALUES (?, ?)";

        try (
            PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, 0); 
            stmt.setDouble(2, 0.0); 
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                orderId = rs.getInt(1); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderId;
    }
}
