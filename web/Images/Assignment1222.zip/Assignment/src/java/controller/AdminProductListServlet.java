package controller;

import entity.Product;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.ProductService;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminProductListServlet", urlPatterns = {"/productlistadmin"})
public class AdminProductListServlet extends HttpServlet {

    // Số sản phẩm mỗi trang
    private static final int PAGE_SIZE = 10;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            ProductService productService = new ProductService();

            // Lấy tham số trang hiện tại, mặc định là 1
            String pageStr = request.getParameter("page");
            int currentPage = 1;
            if (pageStr != null && !pageStr.trim().isEmpty()) {
                try {
                    currentPage = Integer.parseInt(pageStr);
                } catch (NumberFormatException ex) {
                    currentPage = 1;
                }
            }

            int offset = (currentPage - 1) * PAGE_SIZE;
            List<Product> listP = productService.getProductsPaginated(offset, PAGE_SIZE);
            int totalProducts = productService.getProductsCount();
            int totalPages = (int) Math.ceil((double) totalProducts / PAGE_SIZE);

            request.setAttribute("listP", listP);
            request.setAttribute("currentPage", currentPage);
            request.setAttribute("totalPages", totalPages);

            request.getRequestDispatcher("Product/productListAdmin.jsp").forward(request, response);
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
}
